'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Check, Download, Play, Scissors, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { type Clip, formatDuration, formatTimestamp } from '@/lib/clips'

export function ClipCard({ clip, index }: { clip: Clip; index: number }) {
  const [downloaded, setDownloaded] = useState(false)

  function handleDownload() {
    setDownloaded(true)
    // Simulated download — reset the confirmation after a moment.
    window.setTimeout(() => setDownloaded(false), 2000)
  }

  const scoreColor =
    clip.score >= 90
      ? 'text-primary'
      : clip.score >= 80
        ? 'text-chart-2'
        : 'text-muted-foreground'

  return (
    <article
      className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-colors hover:border-primary/50"
      style={{ animation: `clip-in 0.5s ease-out ${index * 80}ms both` }}
    >
      <div className="relative aspect-[9/16] overflow-hidden bg-muted">
        <Image
          src={clip.thumbnail || '/placeholder.svg'}
          alt={`Preview of clip: ${clip.title}`}
          fill
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 260px"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {/* gradient scrim for legibility */}
        <div className="absolute inset-0 bg-gradient-to-t from-background/85 via-background/10 to-transparent" />

        {/* play affordance */}
        <button
          type="button"
          aria-label={`Play preview of ${clip.title}`}
          className="absolute inset-0 flex items-center justify-center"
        >
          <span className="flex size-12 items-center justify-center rounded-full bg-background/70 text-foreground opacity-0 backdrop-blur-sm transition-all duration-300 group-hover:opacity-100 group-hover:scale-100 scale-90">
            <Play className="size-5 translate-x-0.5 fill-current" />
          </span>
        </button>

        <Badge className="absolute left-2.5 top-2.5 gap-1 border-primary/30 bg-background/70 text-primary backdrop-blur-sm">
          <Sparkles className="size-3" />
          {clip.score}
        </Badge>

        <span className="absolute bottom-2.5 right-2.5 rounded-md bg-background/80 px-1.5 py-0.5 font-mono text-xs text-foreground backdrop-blur-sm">
          {formatDuration(clip.duration)}
        </span>
      </div>

      <div className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex-1">
          <h3 className="text-pretty text-sm font-semibold leading-snug">
            {clip.title}
          </h3>
          <p className="mt-1.5 flex items-center gap-1.5 text-xs text-muted-foreground">
            <Scissors className="size-3 shrink-0" />
            <span className="truncate">{clip.reason}</span>
          </p>
        </div>

        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span className="font-mono">@ {formatTimestamp(clip.start)}</span>
          <span className={cn('font-medium', scoreColor)}>
            {clip.score >= 90 ? 'Viral pick' : clip.score >= 80 ? 'Strong' : 'Good'}
          </span>
        </div>

        <Button
          onClick={handleDownload}
          variant={downloaded ? 'secondary' : 'default'}
          className="w-full"
        >
          {downloaded ? (
            <>
              <Check className="size-4" />
              Saved
            </>
          ) : (
            <>
              <Download className="size-4" />
              Download
            </>
          )}
        </Button>
      </div>
    </article>
  )
}
