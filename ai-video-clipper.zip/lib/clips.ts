export type Clip = {
  id: string
  title: string
  thumbnail: string
  /** duration in seconds */
  duration: number
  /** start time in the source video, seconds */
  start: number
  /** AI virality/engagement score 0-100 */
  score: number
  /** short reason the AI picked this moment */
  reason: string
}

export function formatDuration(seconds: number) {
  const m = Math.floor(seconds / 60)
  const s = Math.floor(seconds % 60)
  return `${m}:${s.toString().padStart(2, '0')}`
}

export function formatTimestamp(seconds: number) {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = Math.floor(seconds % 60)
  const mm = m.toString().padStart(2, '0')
  const ss = s.toString().padStart(2, '0')
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`
}

export const sampleClips: Clip[] = [
  {
    id: 'clip-1',
    title: 'The one habit that changed everything',
    thumbnail: '/clips/clip-1.png',
    duration: 42,
    start: 128,
    score: 94,
    reason: 'Strong hook in the first 3 seconds',
  },
  {
    id: 'clip-2',
    title: 'Why most people quit too early',
    thumbnail: '/clips/clip-2.png',
    duration: 58,
    start: 642,
    score: 88,
    reason: 'High emotional peak + clear takeaway',
  },
  {
    id: 'clip-3',
    title: 'A framework you can steal today',
    thumbnail: '/clips/clip-3.png',
    duration: 36,
    start: 1180,
    score: 82,
    reason: 'Actionable, highly saveable moment',
  },
  {
    id: 'clip-4',
    title: 'The laugh that broke the interview',
    thumbnail: '/clips/clip-4.png',
    duration: 29,
    start: 1544,
    score: 76,
    reason: 'Authentic, shareable reaction',
  },
]
